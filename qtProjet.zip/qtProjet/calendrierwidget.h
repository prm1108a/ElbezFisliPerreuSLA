#ifndef CALENDRIERWIDGET_H
#define CALENDRIERWIDGET_H


class CalendrierWidget
{
public:
    CalendrierWidget();
};

#endif // CALENDRIERWIDGET_H