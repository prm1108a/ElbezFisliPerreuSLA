#include "timelistwidget.h"
#include <time.h>
#include <QGridLayout>
#include <iostream>
using namespace std;

TimeLine::TimeLine(QWidget *parent) : QListWidget(parent)
{
    time_t theTime = time(NULL);
    struct tm *aTime = localtime(&theTime);

    int day = aTime->tm_mday;
    int month = aTime->tm_mon + 1;

    int semaine = 0;
    if((day > 0) && (day < 8)) semaine = 0;
    if((day > 8) && (day < 16)) semaine = 1;
    if((day > 16) && (day < 24)) semaine = 2;
    if((day > 24) && (day < 32)) semaine = 3;


    setMaximumWidth(200);
    QGridLayout *layoutTimeLine = new QGridLayout;

    mois[0] = "Janvier"; mois[1] = "Février"; mois[2] = "Mars"; mois[3] = "Avril"; mois[4] = "Mai"; mois[5] = "Juin"; mois[6] = "Juillet"; mois[7] = "Août"; mois[8] = "Septembre"; mois[9] = "Octobre";
    mois[10] = "Novembre"; mois[11] = "Décembre";
    semaines[0] = "Semaine 1"; semaines[1] = "Semaine 2"; semaines[2] = "Semaine 3"; semaines[3] = "Semaine 4";
    jours[0] = "Lundi"; jours[1] = "Mardi"; jours[2] = "Mercredi"; jours[3] = "Jeudi"; jours[4] = "Vendredi"; jours[5] = "Samedi"; jours[6] = "Dimanche";
    huits[0] = "1er 8h"; huits[1] = "2nd 8h"; huits[2] = "3ème 8h";

    setStyleSheet("background-image: url(/home/mariep/workspace/qtProjet/line.jpg); background-position: center;");

    QFont fontMois("Helvetica", 18, QFont::Bold);
    QFont fontSemaines("Helvetica", 14, QFont::Normal);
    QFont fontJours("Helvetica", 14, QFont::Normal);
    QFont fontHuits("Helvetica", 14, QFont::Normal);
    for(int i(0); i < 12; i++){
        itemsMois[i] = new QListWidgetItem(mois[i]+"");
        itemsMois[i]->setFont(fontMois);
        itemsMois[i]->setTextAlignment(Qt::AlignCenter);
        addItem(itemsMois[i]);
        for(int j(0); j < 4; j++){
            itemsSemaines[j] = new QListWidgetItem(semaines[j]+"");
            itemsSemaines[j]->setTextColor(Qt::gray);
            itemsSemaines[j]->setFont(fontSemaines);
            itemsSemaines[j]->setTextAlignment(Qt::AlignLeft);
            addItem(itemsSemaines[j]);
            itemsSemaines[j]->setHidden(true);
          //if(i != month-1)
            for(int k(0); k < 7; k++){
                itemsJours[k] = new QListWidgetItem(jours[k]+"");
                itemsJours[k]->setFont(fontJours);
                itemsJours[k]->setTextAlignment(Qt::AlignRight);
                addItem(itemsJours[k]);
                itemsJours[k]->setHidden(true);
               // cout << semaine << endl;
                //if(i != month-1){
                  //  if(j != semaine) {
                    //    cout << "i = " << i << " j = " << j << endl;
                    //}
                //}
                for(int l(0); l < 3; l++)
                {
                    itemsHuits[l] = new QListWidgetItem(huits[l]+"");
                    itemsHuits[l]->setFont(fontHuits);
                    itemsHuits[l]->setTextAlignment(Qt::AlignRight);
                    addItem(itemsHuits[l]);
                    itemsHuits[l]->setHidden(true);
                }
            }
        }
    }
    setLayout(layoutTimeLine);
}

void TimeLine::mousePressEvent(QMouseEvent *event)
{
    QListWidget::mousePressEvent(event);
}

void TimeLine::mouseReleaseEvent(QMouseEvent *event)
{
    string selectedElemName = currentItem()->text().toStdString();
    int selectedIndex = currentRow();
    if(estUnMois(selectedElemName)){

        int dep = selectedIndex+1;
        int fin = dep+116;
        if(item(dep)->isHidden()){
            currentItem()->setTextColor(QColor(198, 54, 24));
            for(int i(dep); i < fin; i+=29){
                item(i)->setHidden(false);
                item(i)->setTextColor(QColor(223, 97, 91));
            }
        } else {
            currentItem()->setTextColor(Qt::black);
            for(int i(dep); i < fin; i++){
                item(i)->setHidden(true);
                item(i)->setTextColor(Qt::black);
            }
        }
    } else if(estUnJour(selectedElemName)){
        int dep = selectedIndex+1;
        int fin = dep+3;
        if(item(dep)->isHidden()){
            for(int i(dep); i < fin; i++){
                item(i)->setHidden(false);
                item(i)->setTextColor(QColor(109, 200, 147));
            }
        } else {
            for(int i(dep); i < fin; i++){
                item(i)->setHidden(true);
            }
        }
    } else if(estUnHuit(selectedElemName)){


    } else if(estUneSemaine(selectedElemName)){
        int dep = selectedIndex+1;
        int fin = dep+28;
        if(item(dep)->isHidden()){
            for(int i(dep); i < fin; i+=4){
                item(i)->setHidden(false);
                item(i)->setTextColor(QColor( 224, 142, 138 ));
               // item(i)->setBackgroundColor(QColor(216, 216, 216));
            }
        } else {
            for(int i(dep); i < fin; i++){
                item(i)->setHidden(true);
            }
        }
    }
    QListWidget::mouseReleaseEvent(event);
}

bool TimeLine::estUnMois(string name){
    for(int i(0); i < 12; i++){
        if(mois[i].toStdString() == name){
            return true;
        }
    }
    return false;
}

bool TimeLine::estUneSemaine(string name){
    for(int i(0); i < 4; i++){
        if(semaines[i].toStdString() == name){
            return true;
        }
    }
    return false;
}

bool TimeLine::estUnJour(string name){
    for(int i(0); i < 7; i++){
        if(jours[i].toStdString() == name){
            return true;
        }
    }
    return false;
}

bool TimeLine::estUnHuit(string name){
    for(int i(0); i < 3; i++){
        if(huits[i].toStdString() == name){
            return true;
        }
    }
    return false;
}
