#ifndef TIMELISTWIDGET_H
#define TIMELISTWIDGET_H


#include <iostream>
using namespace std;

#include <QWidget>
#include <QListWidget>

class TimeLine : public QListWidget
{
    Q_OBJECT
public:
    TimeLine(QWidget *parent = 0);
protected:
    void mousePressEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
    bool estUnMois(string name);
    bool estUneSemaine(string name);
    bool estUnJour(string name);
    bool estUnHuit(string name);
private:
    QListWidgetItem ** itemsMois = new QListWidgetItem*;
    QListWidgetItem ** itemsSemaines = new QListWidgetItem*;
    QListWidgetItem ** itemsJours = new QListWidgetItem*;
    QListWidgetItem ** itemsHuits = new QListWidgetItem*;
    QString mois[12];
    QString semaines[4];
    QString jours[7];
    QString huits[3];
};

#endif // TIMELISTWIDGET_H
